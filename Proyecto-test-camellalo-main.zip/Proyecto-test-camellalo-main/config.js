const config = {
    DB_URL: 'mongodb+srv://nathuser03:nath123@cluster0.erym3wv.mongodb.net/?retryWrites=true&w=majority',
    PORT: 3000,
    HOST: 'localhost'
}

module.exports = config